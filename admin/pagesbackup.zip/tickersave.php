 <?php

include("include.php");
$content=isset($_POST['content']) ? $_POST['content']:'';
$estatus=isset($_POST['estatus']) ? $_POST['estatus']:'';
$tickid=isset($_POST['tickid']) ? $_POST['tickid']:'';
if($estatus==0){
 $q="INSERT INTO `ticker`( `content`) VALUES('$content')";
	 $a=$conn->query($q);
	 
	 header("location:admin-ticker.php");
 }
 if($estatus==3){
	 
	 $a1="UPDATE `ticker` SET `content`='$content' WHERE id='$tickid'";
	  $q1=$conn->query($a1);
	 
	 header("location:admin-ticker.php");
	 
	 }
